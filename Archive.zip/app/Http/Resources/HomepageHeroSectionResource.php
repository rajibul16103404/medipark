<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class HomepageHeroSectionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'subtitle' => $this->subtitle,
            'background_image' => $this->getFullImageUrl($this->background_image),
            'opacity' => $this->opacity,
            'serial' => $this->serial,
            'status' => $this->status?->value,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }

    /**
     * Convert a single image path to a full URL.
     */
    protected function getFullImageUrl(?string $path): ?string
    {
        if (empty($path)) {
            return null;
        }

        // If it's already a full URL (starts with http:// or https://), return it as is
        if (preg_match('/^https?:\/\//', $path)) {
            return $path;
        }

        // For paths starting with /storage, use asset helper
        if (str_starts_with($path, '/storage')) {
            return asset($path);
        }

        // For other relative paths starting with /, use url helper
        if (str_starts_with($path, '/')) {
            return url($path);
        }

        // For storage paths without leading slash, use Storage::url
        // This handles files stored in storage/app/public
        return Storage::url($path);
    }
}
