<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\ContactPageBannerSection>
 */
class ContactPageBannerSectionFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'background_image' => 'http://example.com/banner.jpg',
            'opacity' => '0.5',
            'status' => 'active',
        ];
    }
}
